Josh McElfresh & Lauren Middleton
Linking Firearm Laws to Firearm Deaths - Where's the 'Smoking Gun'?

To run the visualization open index.html.

main.js does the calculations and builds new JSONs
chart.js creates line and bar charts
main.css styles the main page and svg.css styles the charts

We use d3, jquery and data-maps. All are hosted locally. 

The data is in state_data_JSON.js and gun_key.js

The python files were used to create the JSONs in the js data files. 

Enjoy!